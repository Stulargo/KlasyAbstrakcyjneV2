public class Pies extends Zwierze
{
    @Override
    boolean czyZwierzeMaOczy(boolean o)
    {
        return o;
    }
    @Override
    void czyZwierzeJestZPlanetyZiemia()
    {
        System.out.println("Tak, zwierze jest z planety Ziemia");
    }

}
