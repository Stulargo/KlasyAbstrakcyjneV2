public abstract class Shape {

    public void calculateArea(int a){
    }
}
