public abstract class Zwierze {

    abstract boolean czyZwierzeMaOczy(boolean o);

    abstract void czyZwierzeJestZPlanetyZiemia();

    final void czyZwierzeSkladaSieZAtomow(){
        System.out.println("tak jestem zwierzęciem składającym się z atomów");
    }

        boolean czyZwierzeMaRog(boolean r) {
        return r;
    }


}
