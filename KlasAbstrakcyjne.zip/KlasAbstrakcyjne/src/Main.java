public class Main {
    public static void main(String[] args) {
    Circle circle = new Circle(4);
    Square square = new Square(5);

    square.calculateArea(5);
    circle.calculateArea(4);
    System.out.println( );
    System.out.println( );
    System.out.println( );
    Pies pies = new Pies();
    System.out.println(pies.czyZwierzeMaOczy(true));
    pies.czyZwierzeJestZPlanetyZiemia();
    pies.czyZwierzeSkladaSieZAtomow();
    System.out.println(pies.czyZwierzeMaRog(false));
    }
}
