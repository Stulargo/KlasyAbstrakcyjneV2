public class Circle extends Shape{
    int r;
    double pole;
    @Override
    public void calculateArea(int r){
        pole = Math.PI *Math.pow(r,2);
        System.out.println("Wynik to: "+pole);
    }

    public Circle(int r) {
        this.r = r;
    }
}
