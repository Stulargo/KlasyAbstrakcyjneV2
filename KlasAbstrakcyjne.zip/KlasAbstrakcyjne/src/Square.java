public class Square extends Shape{
    int a;
    int pole;
    @Override
    public void calculateArea(int a){
        pole = a*a;
        System.out.println("Wynik to: "+pole);
    }


    public Square(int a) {
        this.a = a;
    }
}
